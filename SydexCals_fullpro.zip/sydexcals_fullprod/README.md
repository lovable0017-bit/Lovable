# SydexCals v2 - Polished Desktop Edition

This version includes UI polish (dark mode, splash), improved Electron security flags, and packaging scripts.

## Security notes
- API keys should be stored locally in the app user data. Use the built-in settings page (or place a `.env` in the app data folder) to set `OPENAI_API_KEY`.
- The renderer has no direct access to Node or filesystem. Only limited IPC channels are exposed via preload (`get-env` and `save-api-key`).
- Do **not** commit `.env` to source control.

## Build (dev)
1. Install deps:
```bash
npm i
```
2. Run dev (Vite + Electron):
```bash
npm run dev
```
This launches the web dev server and opens Electron with hot reload.

## Packaging
```bash
npm run dist
```
This builds the web app and packages the Electron app for your platform. For code signing and auto-update you must configure `electron-builder` credentials (Apple Developer ID, Microsoft SignTool, etc.). See electron-builder docs.

## UI polish
- Dark mode toggle is included in the app UI.
- Splash screen shown while the app loads.
- Improved button styles and rounded cards for an attractive look.

If you want I can now regenerate the ZIP including these improvements and also add a simple Settings UI to the app to set the API key via `sydex.saveApiKey()` call. Tell me if you'd like me to include the Settings component too.


## Code signing

For production builds you should code-sign installers (Apple Developer ID for macOS, Authenticode for Windows). Configure electron-builder with your certs and credentials before running `npm run dist`.
