// electron/main.js (updated with small security flags & appID)
import { app, BrowserWindow, ipcMain } from 'electron'
import path from 'path'
import fs from 'fs'
import os from 'os'
import { spawn } from 'child_process'

if (process.platform === 'win32') {
  try { app.setAppUserModelId('com.sydexcals.app') } catch {}
}

const isDev = process.env.NODE_ENV === 'development' || process.env.ELECTRON_DEV === '1'

function loadLocalEnv() {
  const userEnvPath = path.join(app.getPath('userData'), '.env')
  if (fs.existsSync(userEnvPath)) {
    const txt = fs.readFileSync(userEnvPath, 'utf8')
    for (const line of txt.split(/\\r?\\n/)) {
      const m = line.match(/^([^=]+)=(.*)$/)
      if (m) process.env[m[1].trim()] = m[2].trim()
    }
    return
  }
  const rootEnv = path.join(process.cwd(), '.env')
  if (fs.existsSync(rootEnv)) {
    const txt = fs.readFileSync(rootEnv, 'utf8')
    for (const line of txt.split(/\\r?\\n/)) {
      const m = line.match(/^([^=]+)=(.*)$/)
      if (m) process.env[m[1].trim()] = m[2].trim()
    }
  }
}

loadLocalEnv()

let mainWindow
let serverProc = null

async function startServerBundled() {
  if (process.env.NODE_ENV === 'production') {
    const serverPath = path.join(process.cwd(), 'server.js')
    if (fs.existsSync(serverPath)) {
      serverProc = spawn(process.execPath, [serverPath], {
        env: process.env,
        stdio: 'inherit'
      })
    }
  }
}

async function createWindow() {
  await startServerBundled()
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 820,
    show: false,
    backgroundColor: '#0ea5a4',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      enableRemoteModule: false,
      webSecurity: true
    }
  })

  if (isDev) {
    await mainWindow.loadURL('http://localhost:5173')
  } else {
    await mainWindow.loadFile(path.join(process.cwd(), 'dist', 'index.html'))
  }

  // Remove menu in prod for a cleaner look
  if (!isDev) mainWindow.setMenuBarVisibility(false)

  mainWindow.once('ready-to-show', () => mainWindow.show())
  mainWindow.on('closed', () => (mainWindow = null))
}

app.on('ready', createWindow)
app.on('window-all-closed', () => { if (process.platform !== 'darwin') {
  if (serverProc) serverProc.kill()
  app.quit()
}})
app.on('activate', () => { if (mainWindow === null) createWindow() })

ipcMain.handle('get-env', (evt, key) => {
  const whitelist = ['OPENAI_API_KEY', 'GOOGLE_API_KEY']
  if (!whitelist.includes(key)) return null
  return process.env[key] || null
})

ipcMain.handle('save-api-key', async (evt, obj) => {
  try {
    const userEnvPath = path.join(app.getPath('userData'), '.env')
    let content = ''
    if (fs.existsSync(userEnvPath)) content = fs.readFileSync(userEnvPath, 'utf8')
    for (const k of Object.keys(obj)) {
      const re = new RegExp(`^${k}=.*$`, 'm')
      if (re.test(content)) content = content.replace(re, `${k}=${obj[k]}`)
      else content += `\\n${k}=${obj[k]}`
    }
    fs.writeFileSync(userEnvPath, content.trim() + os.EOL, { mode: 0o600 })
    return { ok: true }
  } catch (e) {
    return { ok: false, error: e.message }
  }
})


// auto-update (electron-updater) scaffolding
try {
  const { autoUpdater } = await (async ()=>{ try { return await import('electron-updater') } catch { return {} } })()
  if (autoUpdater && !isDev) {
    autoUpdater.checkForUpdatesAndNotify().catch(()=>{})
  }
} catch (e) {
  // ignore if electron-updater not installed in dev
}
