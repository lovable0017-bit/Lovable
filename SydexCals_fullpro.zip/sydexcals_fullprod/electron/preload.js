// electron/preload.js (keeps minimal surface area)
import { contextBridge, ipcRenderer } from 'electron'

contextBridge.exposeInMainWorld('sydex', {
  getEnv: (key) => ipcRenderer.invoke('get-env', key),
  saveApiKey: (obj) => ipcRenderer.invoke('save-api-key', obj)
})
