# Offline Solver Package - SydexCals

This package contains:
- GUI Calculator (offline_solver_app.py)
- CLI Solver (offline_solver.py)
- Build script for packaging into executables

## How to Build SydexCals

1. Install requirements:
   ```bash
   pip install -r requirements.txt
   pip install pyinstaller
   ```

2. Set the version in `version.txt` (default: 1.0.0).

3. Run the build script:
   ```bash
   python build_sydexcals.py
   ```

4. Find your executables in the `dist/` folder:
   - **SydexCals_vX.Y.Z** (GUI App)
   - **SydexCals-CLI_vX.Y.Z** (Command-Line Tool)

## Platform Notes
- **Windows**: Produces `.exe`
- **macOS**: Produces `.app`
- **Linux**: Produces a binary

## Sharing
You can share the files from `dist/` directly with others. They don’t need Python installed.
