import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { OpenAI } from 'openai';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.static('public'));

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Health check
app.get('/api/health', (req, res) => res.json({ ok: true, name: 'SydexCals' }));

// AI solve endpoint (simple non-stream + streaming option)
app.post('/api/solve', async (req, res) => {
  try {
    const { prompt, stream = true } = req.body || {};
    if (!prompt || typeof prompt !== 'string') {
      return res.status(400).json({ error: 'Missing prompt' });
    }

    const system = `You are "SydexCals Tutor", a careful math TA. Solve step by step with headings: Given, Goal, Steps, Final Answer. Show formulas and short justifications. Prefer exact forms then decimals. Do not reveal chain-of-thought beyond necessary steps.`;

    if (!stream) {
      const r = await openai.responses.create({
        model: 'gpt-4o-mini',
        input: [
          { role: 'system', content: system },
          { role: 'user', content: prompt }
        ]
      });
      const text = r.output_text || r?.output?.[0]?.content?.[0]?.text || '';
      return res.json({ text });
    }

    // Streaming via SSE
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const streamResp = await openai.responses.stream({
      model: 'gpt-4o-mini',
      input: [
        { role: 'system', content: system },
        { role: 'user', content: prompt }
      ]
    });

    streamResp.on('message', (msg) => {
      const t = msg?.output_text || msg?.delta || '';
      if (t) res.write(`data: ${JSON.stringify({ delta: t })}\n\n`);
    });

    streamResp.on('end', () => {
      res.write('event: done\n');
      res.write('data: [DONE]\n\n');
      res.end();
    });

    streamResp.on('error', (err) => {
      res.write(`event: error\n`);
      res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
      res.end();
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Vite dev or prod support
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 5173;
app.listen(PORT, () => console.log(`SydexCals server on http://localhost:${PORT}`));
