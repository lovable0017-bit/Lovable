
import React, { useEffect, useMemo, useRef, useState } from 'react'
import ThemeToggle from './components/ThemeToggle'
import Settings from './components/Settings'
import { create, all } from 'mathjs'
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import jsPDF from 'jspdf'

// math.js setup
const math = create(all, { number: 'number', precision: 64 })

// Extend math.js with helpers
math.import({
  permute: (n, r) => math.factorial(n) / math.factorial(n - r),
  combination: (n, r) => math.factorial(n) / (math.factorial(r) * math.factorial(n - r)),
  // numeric integral: Simpson's rule
  nintegrate: (f, a, b, n = 1000) => {
    if (a === b) return 0
    if (n % 2 === 1) n += 1
    const h = (b - a) / n
    let s = f(a) + f(b)
    for (let i = 1; i < n; i++) {
      const x = a + i * h
      s += (i % 2 === 0 ? 2 : 4) * f(x)
    }
    return (h / 3) * s
  },
  // numeric root finder: bracket + bisection fallback + Newton
  nroot: (f, guess = 0, maxIter = 50, tol = 1e-8) => {
    let x = guess
    const df = (x) => (f(x + 1e-6) - f(x - 1e-6)) / 2e-6
    for (let i = 0; i < maxIter; i++) {
      const y = f(x)
      const d = df(x)
      if (!isFinite(d) || Math.abs(d) < 1e-12) break
      const nx = x - y / d
      if (Math.abs(nx - x) < tol) return nx
      x = nx
    }
    // bisection around guess if Newton didn't converge
    let a = guess - 10, b = guess + 10
    let fa = f(a), fb = f(b)
    if (fa * fb > 0) return x // give up
    for (let i = 0; i < 100; i++) {
      const m = 0.5 * (a + b)
      const fm = f(m)
      if (Math.abs(fm) < tol) return m
      if (fa * fm <= 0) { b = m; fb = fm } else { a = m; fa = fm }
    }
    return 0.5 * (a + b)
  }
})

const BTN = ({ children, onClick, className = '', ariaLabel, disabled }) => (
  <button
    onClick={onClick}
    disabled={disabled}
    aria-label={ariaLabel || (typeof children === 'string' ? children : undefined)}
    className={`rounded-2xl shadow-sm px-3 py-2 text-base font-medium border ${disabled ? 'opacity-60 cursor-not-allowed' : 'active:scale-[.98]'} bg-white hover:bg-slate-100 border-slate-200 ${className}`}
  >
    {children}
  </button>
)

const Key = ({ label, onPress, className='' }) => (
  <BTN onClick={() => onPress(label)} className={`text-slate-800 ${className}`}>{label}</BTN>
)

const useLocal = (k, v) => {
  const [val, setVal] = useState(() => {
    try { const x = localStorage.getItem(k); return x ? JSON.parse(x) : v } catch { return v }
  })
  useEffect(() => { try { localStorage.setItem(k, JSON.stringify(val)) } catch {} }, [k, val])
  return [val, setVal]
}

const formatResult = (x) => {
  try {
    if (typeof x === 'number') return (Math.abs(x) < 1e-12 ? 0 : x).toString()
    return math.format(x, { precision: 14 })
  } catch { return String(x) }
}

export default function App() {
  const [expr, setExpr] = useState('')
  const [display, setDisplay] = useState('0')
  const [history, setHistory] = useLocal('sydex.history', [])
  const [memory, setMemory] = useLocal('sydex.memory', 0)

  useEffect(() => {
    const chk = async () => {
      try {
        const r = await fetch('/api/health')
        if (r.ok) {
          const j = await r.json()
          if (j?.ok) { setOnlineMode('online'); return }
        }
        setOnlineMode('offline')
      } catch (e) { setOnlineMode('offline') }
    }
    chk()
  }, [])
  const [deg, setDeg] = useLocal('sydex.deg', true)

  const [graphExprs, setGraphExprs] = useLocal('sydex.graphExprs', 'sin(x); cos(x); x^2/10')
  const [range, setRange] = useLocal('sydex.range', { from: -10, to: 10, step: 0.1 })

  const [aiInput, setAiInput] = useState('Solve: ∫_{0}^{2} (3x^2) dx')
  const [aiText, setAiText] = useState('')
  const [aiBusy, setAiBusy] = useState(false)
  const [onlineMode, setOnlineMode] = useState('unknown')

  const [solveInput, setSolveInput] = useState('x^2 - 5x + 6 = 0')
  const [solveGuess, setSolveGuess] = useState(1)
  const [solveOut, setSolveOut] = useState('')

  const [unitValue, setUnitValue] = useState('5')
  const [unitFrom, setUnitFrom] = useState('cm')
  const [unitTo, setUnitTo] = useState('inch')
  const [unitOut, setUnitOut] = useState('')

  const [matrixA, setMatrixA] = useState('[[2,1],[5,3]]')
  const [matrixB, setMatrixB] = useState('[[1,0],[0,1]]')
  const [matrixOut, setMatrixOut] = useState('')

  // Angle mode (override trig to respect DEG/RAD)
  useEffect(() => {
    if (deg) {
      math.import({
        sin: (x) => Math.sin(math.unit(x, 'deg').toNumber('rad')),
        cos: (x) => Math.cos(math.unit(x, 'deg').toNumber('rad')),
        tan: (x) => Math.tan(math.unit(x, 'deg').toNumber('rad')),
        asin: (x) => math.unit(Math.asin(x), 'rad').toNumber('deg'),
        acos: (x) => math.unit(Math.acos(x), 'rad').toNumber('deg'),
        atan: (x) => math.unit(Math.atan(x), 'rad').toNumber('deg')
      }, { override: true })
    } else {
      math.import({
        sin: (x) => Math.sin(x), cos: (x) => Math.cos(x), tan: (x) => Math.tan(x),
        asin: (x) => Math.asin(x), acos: (x) => Math.acos(x), atan: (x) => Math.atan(x)
      }, { override: true })
    }
  }, [deg])

  const evaluate = () => {
    try {
      if (!expr.trim()) return
      const res = math.evaluate(expr)
      const out = formatResult(res)
      setDisplay(out)
      const item = { expr, result: out, t: Date.now() }
      setHistory([item, ...history].slice(0, 200))
      setExpr(out)
    } catch (e) {
      setDisplay('Error')
    }
  }

  const press = (k) => {
    if (k === 'C') { setExpr(''); setDisplay('0'); return }
    if (k === '⌫') { setExpr(expr.slice(0, -1)); return }
    if (k === '=') { evaluate(); return }
    setExpr((e) => e + k)
  }

  // MULTI-GRAPH data
  const graphSets = useMemo(() => {
    const colors = ['#2563eb','#10b981','#ef4444','#f59e0b','#8b5cf6','#14b8a6']
    return graphExprs.split(/;|\n/).map((s, idx) => ({ expr: s.trim(), color: colors[idx % colors.length] })).filter(g => g.expr)
  }, [graphExprs])

  const graphData = useMemo(() => {
    const obj = {}
    try {
      const { from, to, step } = range
      for (const g of graphSets) {
        const f = math.parse(g.expr).compile()
        const pts = []
        for (let x = from; x <= to; x += step) {
          const y = f.evaluate({ x })
          if (Number.isFinite(y)) pts.push({ x: Number(x.toFixed(4)), [g.expr]: Number(Number(y).toFixed(6)) })
        }
        obj[g.expr] = pts
      }
    } catch {}
    // unify by x
    const keys = Object.keys(obj)
    if (keys.length === 0) return []
    const base = obj[keys[0]].map(p => ({ x: p.x }))
    for (const k of keys) {
      for (let i = 0; i < base.length; i++) {
        base[i][k] = obj[k][i]?.[k]
      }
    }
    return base
  }, [graphSets, range])

  // AI helper (SSE streaming)
  const askAI = async () => {
    setAiText('')
    setAiBusy(true)
    try {
      // try server-side AI first (stream)
      const r = await fetch('/api/solve', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ prompt: aiInput, stream: true }) })
      if (!r.ok) throw new Error('Network error')
      const reader = r.body.getReader()
      const decoder = new TextDecoder()
      let buf = ''
      while (true) {
        const { value, done } = await reader.read()
        if (done) break
        buf += decoder.decode(value, { stream: true })
        const lines = buf.split(/\n\n/)
        buf = lines.pop() || ''
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const payload = JSON.parse(line.slice(6))
            if (payload.delta) setAiText((t) => t + payload.delta)
          }
        }
      }
      setAiBusy(false)
      return
    } catch (e) {
      // fallback to offline solver
      try {
        const res = await OfflineSolver.offlineSolve(aiInput)
        if (res && res.ok) {
          let out = ''
          if (res.mode === 'eval') out = `Evaluation result:\n${res.result}`
          else if (res.mode === 'integral') out = `Definite integral of ${res.expr} from ${res.a} to ${res.b} ≈ ${res.result}`
          else if (res.mode === 'derivative') out = `Derivative of ${res.expr} at x=${res.at} ≈ ${res.result}`
          else if (res.mode === 'derivative-symbolic') out = `Symbolic derivative of ${res.expr}: ${res.result}`
          else if (res.mode === 'equation') out = `Roots for ${res.equation}: ${res.roots}`
          else if (res.mode === 'linalg') out = `Linear algebra result: ${res.result}`
          else out = JSON.stringify(res)
          setAiText(out)
        } else {
          setAiText('Offline solver could not parse the problem.\\n' + (res.error || 'Unknown error') + '\\n\\nOriginal error: ' + e.message)
        }
      } catch (ee) {
        setAiText('Offline solver failed: ' + ee.message + '\\nOriginal error: ' + e.message)
      } finally {
        setAiBusy(false)
      }
    }
  }
const exportPDF = () => {
    const doc = new jsPDF({ unit: 'pt', format: 'a4' })
    const margin = 40
    const maxWidth = 515
    const lines = doc.splitTextToSize(aiText || 'No AI output yet.', maxWidth)
    doc.setFont('Times', 'Normal')
    doc.setFontSize(14)
    doc.text('SydexCals – AI Solution', margin, margin)
    doc.setFontSize(11)
    let y = margin + 20
    for (const ln of lines) {
      if (y > 780) { doc.addPage(); y = margin }
      doc.text(ln, margin, y); y += 16
    }
    doc.save('SydexCals_AI_Steps.pdf')
  }

  // SOLVER helpers
  const solveEquation = () => {
    try {
      const raw = solveInput
      // Split on '=' into left-right, build f(x) = left-right
      const [L, R] = raw.split('=')
      const diff = `${L} - (${R ?? 0})`
      const node = math.parse(diff)
      const f = node.compile()
      const fnum = (x) => {
        const v = f.evaluate({ x })
        return Number(v)
      }

      const guesses = [-10,-5,-2,-1,0,1,2,5,10].map(g => g + Number(solveGuess||0))
      const roots = new Set()
      for (const g of guesses) {
        const r = math.nroot ? math.nroot(fnum, g) : math.evaluate('nroot(f, g)', { f: fnum, g })
        if (isFinite(r)) {
          const rr = Number(r.toFixed(8))
          if (!Array.from(roots).some(x => Math.abs(x - rr) < 1e-6)) roots.add(rr)
        }
      }
      const out = Array.from(roots).sort((a,b)=>a-b)
      setSolveOut(out.length ? `Roots ≈ ${out.join(', ')}` : 'No numeric roots found near guesses.')
    } catch (e) {
      setSolveOut('Error: ' + e.message)
    }
  }

  const solveLinearSystem = () => {
    try {
      const A = math.evaluate(matrixA)
      const b = math.evaluate(matrixB)
      const x = math.lusolve(A, b)
      setMatrixOut('Solution: ' + formatResult(x))
    } catch (e) {
      setMatrixOut('Error: ' + e.message)
    }
  }

  const unitConvert = () => {
    try {
      const v = math.unit(Number(unitValue), unitFrom).toNumber(unitTo)
      setUnitOut(`${unitValue} ${unitFrom} = ${v} ${unitTo}`)
    } catch (e) {
      setUnitOut('Error: ' + e.message)
    }
  }

  const derivativeAt = (fx, x0) => {
    try {
      const d = math.derivative(fx, 'x')
      const compiled = d.compile()
      return compiled.evaluate({ x: x0 })
    } catch {
      return NaN
    }
  }

  const integralOf = (fx, a, b) => {
    try {
      const compiled = math.parse(fx).compile()
      const f = (x) => Number(compiled.evaluate({ x }))
      return math.nintegrate(f, a, b, 1000)
    } catch {
      return NaN
    }
  }

  return (
    <div className="max-w-6xl mx-auto p-4 grid grid-cols-1 lg:grid-cols-2 gap-4">
      <header className="lg:col-span-2 flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800">SydexCals</h1>
        <div className="text-sm text-slate-600">Deg/Rad:
          <button className={`ml-2 px-3 py-1 rounded-full border ${deg ? 'bg-blue-100 border-blue-300' : 'bg-white border-slate-300'}`} onClick={() => setDeg(true)}>DEG</button>
          <button className={`ml-2 px-3 py-1 rounded-full border ${!deg ? 'bg-blue-100 border-blue-300' : 'bg-white border-slate-300'}`} onClick={() => setDeg(false)}>RAD</button>
        </div>
        <div className="text-sm ml-4">Mode: {onlineMode === 'online' ? <span className="text-green-600">Online</span> : onlineMode === 'offline' ? <span className="text-amber-500">Offline</span> : <span className="text-slate-500">Unknown</span>}</div>
      </header>

      {/* Calculator Panel */}
      <section className="bg-white rounded-2xl shadow p-4">
        <div className="border rounded-xl p-3 bg-slate-50 text-right font-mono text-2xl overflow-x-auto">
          <div className="text-slate-400 text-sm">{deg ? 'DEG' : 'RAD'}</div>
          <div className="text-slate-500 text-base">{expr || ' '}</div>
          <div className="text-slate-900 text-3xl">{display}</div>
        </div>

        <div className="grid grid-cols-5 gap-2 mt-3">
          <BTN className="bg-rose-50" onClick={() => press('C')}>C</BTN>
# trimmed in file for brevity - full content included in package
