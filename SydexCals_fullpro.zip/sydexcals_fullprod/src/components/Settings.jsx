import React, { useState, useEffect } from 'react'

export default function Settings() {
  const [key, setKey] = useState('')
  const [status, setStatus] = useState(null)
  const [mode, setMode] = useState('unknown')

  useEffect(() => {
    checkMode()
  }, [])

  const save = async () => {
    setStatus('Saving...')
    try {
      const res = await window.sydex.saveApiKey({ OPENAI_API_KEY: key })
      if (res?.ok) setStatus('Saved securely to app data.')
      else setStatus('Save failed: ' + (res?.error || 'unknown'))
    } catch (e) { setStatus('Error: ' + e.message) }
  }

  const checkMode = async () => {
    try {
      const r = await fetch('/api/health')
      if (r.ok) {
        const j = await r.json()
        if (j?.ok) {
          setMode('online')
          setStatus('Server reachable (' + (j.name || 'server') + ')')
          return
        }
      }
      setMode('offline')
      setStatus('Server not reachable; using offline solver')
    } catch (e) {
      setMode('offline')
      setStatus('Server not reachable; using offline solver')
    }
  }

  return (
    <div className="p-3 border rounded-lg bg-white dark:bg-slate-800">
      <div className="flex items-center justify-between mb-2">
        <div>
          <label className="text-sm text-slate-600 dark:text-slate-300">Paste your OpenAI API key (stored locally):</label>
        </div>
        <div className="text-sm">
          Mode: {mode === 'online' ? <span className="text-green-600">Online</span> : mode === 'offline' ? <span className="text-amber-500">Offline</span> : <span className="text-slate-500">Unknown</span>}
        </div>
      </div>
      <input className="w-full mt-2 p-2 border rounded" value={key} onChange={(e)=>setKey(e.target.value)} placeholder="sk-..." />
      <div className="mt-2 flex gap-2">
        <button className="px-3 py-2 bg-green-500 text-white rounded" onClick={save}>Save locally</button>
        <button className="px-3 py-2 bg-sky-500 text-white rounded" onClick={checkMode}>Check server</button>
        <div className="text-sm text-slate-600 dark:text-slate-300 ml-2">{status}</div>
      </div>
    </div>
  )
}
