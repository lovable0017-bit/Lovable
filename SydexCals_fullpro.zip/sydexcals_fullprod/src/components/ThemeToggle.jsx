import React, { useEffect, useState } from 'react'

export default function ThemeToggle() {
  const [theme, setTheme] = useState(() => {
    try { return localStorage.getItem('sydex.theme') || 'light' } catch { return 'light' }
  })

  useEffect(() => {
    document.documentElement.classList.remove('dark','light')
    document.documentElement.classList.add(theme)
    try { localStorage.setItem('sydex.theme', theme) } catch {}
  }, [theme])

  return (
    <div className="flex items-center gap-2">
      <button onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
        className="px-3 py-1 rounded-full border bg-white/90 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 shadow-sm">
        {theme === 'light' ? '🌙 Dark' : '☀️ Light'}
      </button>
    </div>
  )
}
