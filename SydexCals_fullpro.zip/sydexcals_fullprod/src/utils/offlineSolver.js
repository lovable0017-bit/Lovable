// Enhanced offline math helper for SydexCals with stepwise explanations
import { create, all } from 'mathjs'
const math = create(all, { number: 'number', precision: 64 })

function formatNumber(x) {
  try { return math.format(x, { precision: 14 }) } catch { return String(x) }
}

function tryEvaluateExpression(expr) {
  try {
    const parsed = math.parse(expr)
    const compiled = parsed.compile()
    const v = compiled.evaluate()
    const steps = []
    steps.push(`Parsed expression: ${parsed.toString()}`)
    steps.push(`Evaluated numeric value: ${formatNumber(v)}`)
    return { ok: true, type: 'evaluation', result: formatNumber(v), steps }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}

function tryDefiniteIntegral(expr) {
  try {
    // support forms like "integral of x^2 from 0 to 2" or "∫ from 0 to 2 x^2 dx"
    const m = expr.match(/(?:integral|∫)[^\\d\\-]*([\\s\\S]+?)from\\s*([\\-0-9\\.]+)\\s*to\\s*([\\-0-9\\.]+)/i)
    if (m) {
      const fx = m[1].trim().replace(/dx$/i,'').trim()
      const a = parseFloat(m[2])
      const b = parseFloat(m[3])
      const node = math.parse(fx)
      const f = node.compile()
      // numeric Simpson's rule with explanation steps
      const n = 200  // reasonably fine
      const h = (b - a) / n
      let s = f.evaluate({x:a}) + f.evaluate({x:b})
      const steps = []
      steps.push(`Integrand: ${node.toString()}`)
      steps.push(`Interval: [${a}, ${b}], using Simpson's rule with n=${n} subintervals`)
      for (let i = 1; i < n; i++) {
        const x = a + i * h
        const fxval = f.evaluate({x})
        s += (i % 2 === 0 ? 2 : 4) * fxval
        if (i <= 3 || i > n-3) { // include a few sample interior evaluations for steps
          steps.push(`f(${formatNumber(x)}) = ${formatNumber(fxval)}`)
        }
      }
      const val = (h / 3) * s
      steps.push(`Simpson approximation: ${formatNumber(val)}`)
      return { ok: true, type: 'integral', expr: fx, a, b, result: formatNumber(val), steps }
    }
  } catch (e) { return { ok:false, error: e.message } }
  return { ok:false, error:'No integral pattern found' }
}

function tryDerivative(expr) {
  try {
    // pattern: "derivative of <fx> at <x>" or "d/dx <fx> at <x>"
    const m = expr.match(/(?:derivative|d\\/dx)[^\\d]*([\\s\\S]+?)(?:at\\s*x?\\s*=?\\s*([\\-0-9\\.]+))?$/i)
    if (m) {
      const fx = m[1].trim()
      const at = m[2] ? parseFloat(m[2]) : null
      const dnode = math.derivative(fx, 'x')
      const steps = []
      steps.push(`Function: ${fx}`)
      steps.push(`Symbolic derivative: ${dnode.toString()}`)
      if (at !== null) {
        const compiled = dnode.compile()
        const val = compiled.evaluate({ x: at })
        steps.push(`Evaluated derivative at x=${at}: ${formatNumber(val)}`)
        return { ok:true, type:'derivative', expr:fx, at, result: formatNumber(val), steps }
      } else {
        return { ok:true, type:'derivative-symbolic', expr:fx, result: dnode.toString(), steps }
      }
    }
  } catch (e) { return { ok:false, error: e.message } }
  return { ok:false, error:'No derivative pattern found' }
}

function trySolveEquation(expr) {
  try {
    // accepts "solve x^2-5x+6=0" or "roots of x^3-2x-5"
    const m = expr.match(/(?:solve|roots|root)[^\\n]*\\s*([^\\n]+)/i)
    let target = null
    if (m) target = m[1].trim()
    if (!target) {
      if (expr.includes('=')) target = expr
    }
    if (target) {
      let equation = target
      if (equation.includes('=')) {
        const parts = equation.split('=')
        equation = `(${parts[0]})-(${parts[1]})`
      }
      const node = math.simplify(equation)
      const fnode = math.parse(equation)
      const f = fnode.compile()
      const steps = []
      steps.push(`Transformed equation to f(x)=0 where f(x) = ${fnode.toString()}`)
      // numeric root finding with Newton-Raphson from multiple guesses
      const guesses = [-10,-5,-2,-1,0,1,2,5,10]
      const roots = new Set()
      for (const g0 of guesses) {
        let x = g0
        let converged = false
        for (let i=0;i<80;i++) {
          try {
            const y = f.evaluate({ x })
            const dy = (f.evaluate({ x: x + 1e-6 }) - f.evaluate({ x: x - 1e-6 })) / 2e-6
            if (!isFinite(dy) || Math.abs(dy) < 1e-12) break
            const nx = x - y/dy
            if (Math.abs(nx - x) < 1e-9) { x = nx; converged = true; break }
            x = nx
          } catch (e) { break }
        }
        if (converged && isFinite(x)) {
          roots.add(Number(x.toFixed(10)))
          steps.push(`Guess ${g0} → converged to ${Number(x.toFixed(10))}`)
        } else {
          steps.push(`Guess ${g0} → no convergence`)
        }
      }
      const out = Array.from(roots).sort((a,b)=>a-b)
      if (out.length) return { ok:true, type:'roots', equation, roots: out, steps }
      return { ok:false, error:'No numeric roots found', steps }
    }
  } catch (e) { return { ok:false, error: e.message } }
  return { ok:false, error:'No equation pattern found' }
}

function tryLinearAlgebra(expr) {
  try {
    if (/det|inverse|inv|solve|lusolve/i.test(expr)) {
      const m = expr.match(/(det|inv|inverse|solve|lusolve)\\s*\\(?\\s*([\\s\\S]+)\\s*\\)?/i)
      if (m) {
        const op = m[1].toLowerCase()
        const data = m[2]
        const A = math.evaluate(data)
        const steps = []
        steps.push(`Parsed data: ${JSON.stringify(A).slice(0,200)}`)
        if (op.includes('det')) {
          const val = math.det(A)
          steps.push(`det(A) = ${formatNumber(val)}`)
          return { ok:true, type:'det', result: formatNumber(val), steps }
        }
        if (op.includes('inv')||op.includes('inverse')) {
          const val = math.inv(A)
          steps.push(`inv(A) computed`)
          return { ok:true, type:'inv', result: formatNumber(val), steps }
        }
        if (op.includes('solve')||op.includes('lusolve')) {
          // expects A to be [A, b] or two matrices
          let res = null
          try {
            if (Array.isArray(A) && Array.isArray(A[0]) && !Array.isArray(A[0][0])) {
              // ambiguous; return A info
              steps.push('Data looks like a flat array; returning raw evaluation.')
              return { ok:true, type:'raw', result: formatNumber(A), steps }
            }
            // attempt solving: if data is [A,b] where A is matrix and b is vector
            if (Array.isArray(A) && A.length === 2) {
              res = math.lusolve(A[0], A[1])
            } else {
              res = math.lusolve(A)
            }
          } catch(e) {
            return { ok:false, error: e.message }
          }
          steps.push('Solved linear system with lusolve')
          return { ok:true, type:'solve', result: formatNumber(res), steps }
        }
      }
    }
  } catch (e) { return { ok:false, error: e.message } }
  return { ok:false, error:'No linear algebra pattern found' }
}

export async function offlineSolve(prompt) {
  const text = (prompt || '').toString()
  const heuristics = [
    tryEvaluateExpression,
    tryDefiniteIntegral,
    tryDerivative,
    trySolveEquation,
    tryLinearAlgebra
  ]
  for (const h of heuristics) {
    try {
      const r = h(text)
      if (r && r.ok) return r
    } catch (e) {
      // ignore and continue
    }
  }
  return { mode: 'none', ok:false, error: 'Could not parse the problem for offline solving. Try a simpler request like \"integral of x^2 from 0 to 2\" or \"derivative of sin(x) at x=1\" or an expression to evaluate.' }
}
export default { offlineSolve }
