// Simple test runner for offlineSolver (no external test framework required)
// Run with: node --experimental-modules tests/offlineSolver_test.mjs
import Offline from '../src/utils/offlineSolver.js'

async function run() {
  const cases = [
    {name: 'eval', input: '2+3*4'},
    {name: 'integral', input: 'integral of x^2 from 0 to 2'},
    {name: 'derivative', input: 'derivative of x^3 at 2'},
    {name: 'solve', input: 'solve x^2-5x+6=0'},
    {name: 'det', input: 'det([[1,2],[3,4]])'}
  ]
  for (const c of cases) {
    try {
      const r = await Offline.offlineSolve(c.input)
      console.log('CASE:', c.name, 'INPUT:', c.input)
      console.log('RESULT:', JSON.stringify(r, null, 2))
      if (!r.ok) {
        console.error('❌ Test failed (not ok).')
      } else {
        console.log('✅ OK\n')
      }
    } catch (e) {
      console.error('❌ Error running case', c.name, e)
    }
  }
}
run()
