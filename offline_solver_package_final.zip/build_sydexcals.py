import os
import platform
import subprocess

def get_version():
    with open("version.txt", "r") as f:
        return f.read().strip()

def build_app():
    version = get_version()
    system = platform.system()
    icon = os.path.join("assets", "icon.png")
    
    if system == "Windows":
        cmd = [
            "pyinstaller",
            "--onefile",
            "--noconsole",
            f"--icon={icon}",
            "--name", f"SydexCals_v{version}",
            "offline_solver_app.py"
        ]
        cli_cmd = [
            "pyinstaller",
            "--onefile",
            "--console",
            "--name", f"SydexCals-CLI_v{version}",
            "offline_solver.py"
        ]
    elif system == "Darwin":
        cmd = [
            "pyinstaller",
            "--onefile",
            "--windowed",
            f"--icon={icon}",
            "--name", f"SydexCals_v{version}",
            "offline_solver_app.py"
        ]
        cli_cmd = [
            "pyinstaller",
            "--onefile",
            "--console",
            "--name", f"SydexCals-CLI_v{version}",
            "offline_solver.py"
        ]
    else:
        cmd = [
            "pyinstaller",
            "--onefile",
            "--noconsole",
            "--name", f"SydexCals_v{version}",
            "offline_solver_app.py"
        ]
        cli_cmd = [
            "pyinstaller",
            "--onefile",
            "--console",
            "--name", f"SydexCals-CLI_v{version}",
            "offline_solver.py"
        ]
    
    print("Building GUI app...")
    subprocess.run(cmd)
    print("Building CLI app...")
    subprocess.run(cli_cmd)

if __name__ == "__main__":
    build_app()
